//
//  ViewController.swift
//  Ardliapps
//
//  Created by Miftahul Ardli on 22/09/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var fakultasTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        fakultasTableView.dataSource = self
        fakultasTableView.delegate = self
        
        // MARK: Mendaftarkan XIB ke ViewController.
        fakultasTableView.register(
          UINib(nibName: "FakultasTableViewCell", bundle: nil),
          forCellReuseIdentifier: "FakultasCell"
        )
      }
    @IBAction func goToWebsite(_ sender: Any) {
        let urlUnpad = "https://www.unpad.ac.id"
        if let url = URL(string: urlUnpad), UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
          }}
}
     
    // MARK: Mengimplementasikan UITableViewDataSource ke dalam ViewController.
    extension ViewController: UITableViewDataSource {
     
      // MARK: Mengetahui berapa banyak item yang akan muncul.
      func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
      ) -> Int {
     
        // MARK: Mendapatkan jumlah item dari dummyAcademyData.
        return dummyFakultasdata.count
      }
     
      // MARK: Mengatur bagaimana tampilan dari setiap TableViewCell.
      func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
      ) -> UITableViewCell {
     
        // MARK: Mencari AcademyTableViewCell berdasarkan Identifier.
        if let cell = tableView.dequeueReusableCell(
          withIdentifier: "FakultasCell",
          for: indexPath
        ) as? FakultasTableViewCell {
     
          // MARK: Menetapkan nilai gambar dan nama untuk setiap cell/item.
          let academy = dummyFakultasdata[indexPath.row]
          cell.fakultasLabel.text = academy.name
          cell.fakultasImageView.image = academy.image
     
          // MARK: Mengembalikan cell agar bisa ditampilkan dalam TableView.
          return cell
        } else {
     
          // MARK: Mengembalikan UITableViewCell ketika cell bernilai nil/null.
          return UITableViewCell()
        }
      }
    }
     

extension ViewController: UITableViewDelegate {
  func tableView(
    _ tableView: UITableView,
    didSelectRowAt indexPath: IndexPath
  ) {
    performSegue(withIdentifier: "moveToDetail",
                 sender: dummyFakultasdata[indexPath.row])
  }
   override func prepare(
        for segue: UIStoryboardSegue,
        sender: Any?
      ) {
        if segue.identifier == "moveToDetail" {
          if let detaiViewController = segue.destination as? DetailViewController {
            detaiViewController.fakultas = sender as? FakultasModel
          }
        }
      }
}
