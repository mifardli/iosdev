//
//  FakultasTableViewCell.swift
//  Ardliapps
//
//  Created by Miftahul Ardli on 22/09/23.
//

import UIKit

class FakultasTableViewCell: UITableViewCell {

    @IBOutlet var fakultasLabel: UILabel!
    @IBOutlet var fakultasImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
