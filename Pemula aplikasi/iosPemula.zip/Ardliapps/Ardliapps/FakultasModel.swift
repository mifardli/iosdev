//
//  FakultasModel.swift
//  Ardliapps
//
//  Created by Miftahul Ardli on 22/09/23.
//

import Foundation
import UIKit
struct FakultasModel {
  let id: Int
  let name: String
  let image: UIImage
  let description: String
}

let dummyFakultasdata = [
  FakultasModel(
    id: 1,
    name: "Fakultas Pertanian",
    image: UIImage(named: "Fakultas-Pertanian-Unpad")!,
    description: "Pada tanggal 1 September 1959 Fakultas Pertanian Unpad resmi didirikan berdasarkan SK Menteri PP&K No. 85633/S. Fakultas Pertanian merupakan fakultas ke-5 yang didirikan oleh Unpad, yang berlokasi di Bandung, ibukota provinsi Jawa Barat, Indonesia."
  ), FakultasModel(
    id: 2,
    name: "Fakultas Kedokteran",
    image: UIImage(named: "pages-MjA-20191001120319")!,
    description: "Gagasan untuk mendirikan Fakultas Kedokteran pertama kali datang dari menteri kesehatan dr. Lie Kiat Teng pada Kongres IDI di Surabaya tahun 1953. Pada saat itu banyak dokter lulusan Fakultas Kedokteran Universitas Indonesia yang ditahan di FKUI untuk memenuhi kebutuhan staf pengajar di FKUI."
  ), FakultasModel(
    id: 3,
    name: "Fakultas Perikanan",
    image: UIImage(named: "humas-unpad-FPIK-1")!,
    description: "Program Studi Perikanan Fakultas Perikanan dan Ilmu Kelautan (FPIK) Unpad mempelajari berbagai ilmu yang dapat menghatarkan kepada kemampuan untuk dapat mengelola dan membudiyakan ikan mulai dari pembenihan ataupun pembesaran untuk ikan konsumsi maupun ikan hias, menformulasikan pakan, mencegah dan menanggulangi penyakit ikan, mengelola lingkungan perairan untuk kehidupan sumberdaya hayati perairan, mengelola penangkapan ikan laut, menyusun kelayakan usaha kegiatan perikanan, mengelola industri pengolahan hasil perikanan, mengelola manajemen mutu produk pengolahan hasil perikanan untuk ekspor, mengelola dan memanfaatkan  limbah dari kegiatan perikanan."
  ), FakultasModel(
    id: 4,
    name: "Fakultas Farmasi",
    image: UIImage(named: "Farmasi_Dekanat_Unpad_2016")!,
    description: "Fakultas Farmasi sebelumnya berstatus Jurusan Farmasi di bawah Fakultas Matematika dan Ilmu Pengetahuan Alam (1959-2006) dan merupakan satu diantara 16 Fakultas di Universitas Padjadjaran. FF-Unpad merupakan salah satu institusi pendidikan di Indonesia dengan program studi yang terdiri dari Program Sarjana (S1), Program Profesi (Apoteker), Program Magister Farmasi (S2), Program Magister Farmasi Klinik (S2) dan Program Doktor Farmasi (S3)."
  ), FakultasModel(
    id: 5,
    name: "Fakultas Keperawatan",
    image: UIImage(named: "fkeperawatan")!,
    description: "Fakultas Keperawatan Unpad sebagai pusat Pendidikan Tinggi Keperawatan tertua kedua di Indonesia dituntut untuk menghasilkan sumber daya manusia keperawatan yang berkualitas tinggi. Oleh sebab itu, Fakultas Keperawatan Unpad berupaya menata dan mengelola segala sumber daya yang dimiliki serta mengembangkan diri sehingga menghasilkan lulusan yang mampu bersaing di pasaran kerja nasional maupun internasional."
  ), FakultasModel(
    id: 6,
    name: "Fakultas Kedokteran Gigi",
    image: UIImage(named: "unpad-e1637655822154.original")!,
    description: "Fakultas Kedokteran Gigi (FKG) Unpad terbentuk pada tanggal 1 September 1959 berdasarkan SK Menteri Pendidikan dan Kebudayaan Nomor 85633/S. FKG Unpad terbentuk berkat upaya Panitia Pembentukan FKG Unpad yang terdiri dari Prof. Dr. R. Moestopo, Prof. Soeria Soemantri, MPH., R. Soeriadiredja, dr. Chasan Boesoeri, dan Prof. Dr. Naubaeuer."
  ), FakultasModel(
    id: 7,
    name: "Fakultas Peternakan",
    image: UIImage(named: "fapet")!,
    description: "Fakultas Peternakan Universitas Padjadjaran yang dirintis oleh Prof. Dr. Didi Atmadilaga berdiri Tahun 1963 berdasarkan SK Menteri PTIP No.86/63 Tanggal 27 Juli 1963 dan diresmikan pada Tanggal 1 September 1963."
  ), FakultasModel(
    id: 8,
    name: "Fakultas Teknik Geologi",
    image: UIImage(named: "ftgunpad")!,
    description: "Berdiri pada tahun 1959 sebagai Jurusan Geologi di bawah naungan Fakultas Ilmu Pasti dan Ilmu Alam Unpad dengan pendiri utama Mayor Jendral (Purn) Prof. Dr. Moestopo dan Drs. Koesmono. Kegiatan resmi dimulai tanggal 17 November 1959 dengan mahasiswa berjumlah 17 orang. Kegiatan perkuliahan dibina oleh dosen tetap Drs. Koesmono dan tiga dosen luar biasa, yaitu Dr. S. Sartono, Drs. R. Soeria Atmadja, dan Drs. A. Asikin."
  ),   FakultasModel(
    id: 9,
    name: "Fakultas Psikologi",
    image: UIImage(named: "fapsiunpad")!,
    description: "Fakultas Psikologi Universitas Padjadjaran, secara konsisten menghasilkan lulusan Sarjana, Psikolog, Magister Sains, dan Doktor yang mampu menganalisis, mengaplikasikan dan memberikan solusi atas permasalahan Psikologi, serta memiliki kepribadian yang berahlak mulia, terbuka dan kritis, baik dalam level individual, organisasional, maupun kelompok masyarakat."
  ), FakultasModel(
    id: 10,
    name: "Fakultas Teknologi Industri Pertanian",
    image: UIImage(named: "ftipunpad")!,
    description: "Fakultas Teknologi Industri Pertanian (FTIP Unpad) diresmikan pada tanggal 13 September 2005. FTIP lahir dari adanya peningkatan Jurusan Teknologi Pertanian (Teknotan) Fakultas Pertanian. FTIP Unpad awalnya memiliki 2 (dua) Program Studi yaitu Teknik Pertanian dan Teknologi Pangan, dan sejak tahun 2014 bertambah satu Program Studi yaitu Teknologi Industri Pertanian."
  )
]
